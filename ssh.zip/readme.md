# Hello from @tcpsyn (Space).

> SSH-KILL and TCP-KILL will work on any server with any specs.
> For the best results use a server with a decent CPU.

# To use these methods simply follow these instructions:

1. Put the methods on your server.
2. Use "chmod 777 *" so you can execute the methods.
3. Run "./SSH-KILL [ip] [port] [threads] [duration]" and "./TCP-KILL [ip] [port] [threads] [duration]" respectively.

> Done!

*Note #1: If you want to use these methods in your API check out https://ssn.sellix.io "SSN API" and message @tcpsyn on Telegram for help setting it up*

*Note #2: To purchase these methods after the trial is over, contact @tcpsyn on Telegram. The pricing is only $20 monthly for each*